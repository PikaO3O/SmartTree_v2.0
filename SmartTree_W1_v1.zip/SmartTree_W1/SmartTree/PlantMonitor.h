#ifndef SMARTTREE_PLANT_MONITOR_H
#define SMARTTREE_PLANT_MONITOR_H

#include <stdint.h>

// 使用 unsigned 差值，跨越 millis() 約 49.7 天的回繞仍可計時。
class PlantMonitor {
public:
    enum State { CHECKING, CONFIRMED, UNCONFIRMED, NN_TIMEOUT, OFFLINE };
    enum Event { NONE, PLANT_CONFIRMED, PLANT_UNCONFIRMED, INFERENCE_TIMEOUT };

    PlantMonitor(uint32_t confirmMs = 2000, uint32_t missingMs = 5000,
                 uint32_t freshnessMs = 1500)
        : confirmMs_(confirmMs), missingMs_(missingMs), freshnessMs_(freshnessMs) {
        reset(0);
    }

    void reset(uint32_t now) {
        state_ = CHECKING;
        committed_ = CHECKING;
        startedAt_ = now;
        lastSampleAt_ = now;
        hasSample_ = false;
        runActive_ = false;
        positiveSamples_ = 0;
        runSince_ = now;
        confirmedEvents_ = 0;
        alertEvents_ = 0;
    }

    // 僅對「新一輪推論」呼叫；重複讀取舊結果不能累積確認時間。
    Event observe(uint32_t sampleAt, bool present, bool discontinuous = false) {
        const bool gap = discontinuous ||
            (hasSample_ && uint32_t(sampleAt - lastSampleAt_) >= freshnessMs_);
        if (gap || state_ == NN_TIMEOUT || state_ == OFFLINE) {
            runActive_ = false;
            committed_ = CHECKING;
        }
        lastSampleAt_ = sampleAt;
        hasSample_ = true;

        if (!runActive_ || present != runPositive_) {
            runActive_ = true;
            runPositive_ = present;
            runSince_ = sampleAt;
            positiveSamples_ = 0;
        }
        if (present && positiveSamples_ < 65535) ++positiveSamples_;

        if (present && uint32_t(sampleAt - runSince_) >= confirmMs_ &&
            positiveSamples_ >= 3) {
            state_ = CONFIRMED;
            if (committed_ != CONFIRMED) {
                committed_ = CONFIRMED;
                ++confirmedEvents_;
                return PLANT_CONFIRMED;
            }
        } else if (!present && uint32_t(sampleAt - runSince_) >= missingMs_) {
            state_ = UNCONFIRMED;
            if (committed_ != UNCONFIRMED) {
                committed_ = UNCONFIRMED;
                ++alertEvents_;
                return PLANT_UNCONFIRMED;
            }
        } else {
            state_ = CHECKING;
        }
        return NONE;
    }

    Event tick(uint32_t now) {
        if (state_ == OFFLINE) return NONE;
        const uint32_t reference = hasSample_ ? lastSampleAt_ : startedAt_;
        if (uint32_t(now - reference) >= freshnessMs_ && state_ != NN_TIMEOUT) {
            state_ = NN_TIMEOUT;
            committed_ = CHECKING;
            runActive_ = false;
            return INFERENCE_TIMEOUT;
        }
        return NONE;
    }

    void offline() {
        state_ = OFFLINE;
        committed_ = CHECKING;
        hasSample_ = false;
        runActive_ = false;
    }

    // 重新連線保留整次開機的事件計數，但重新累積 2 秒／5 秒。
    void reconnect(uint32_t now) {
        state_ = CHECKING;
        committed_ = CHECKING;
        startedAt_ = now;
        hasSample_ = false;
        runActive_ = false;
        positiveSamples_ = 0;
    }

    State state() const { return state_; }
    uint32_t confirms() const { return confirmedEvents_; }
    uint32_t alerts() const { return alertEvents_; }
    uint32_t freshnessMs() const { return freshnessMs_; }

private:
    uint32_t confirmMs_, missingMs_, freshnessMs_;
    uint32_t startedAt_, lastSampleAt_, runSince_;
    uint32_t confirmedEvents_, alertEvents_;
    uint16_t positiveSamples_;
    bool hasSample_, runActive_, runPositive_;
    State state_, committed_;
};

#endif
