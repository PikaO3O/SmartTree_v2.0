#ifndef SMARTTREE_DETECTION_SNAPSHOT_H
#define SMARTTREE_DETECTION_SNAPSHOT_H
#include <stdint.h>

// callback 與 Arduino loop 用 FreeRTOS queue 傳值，不共用正在改寫的 vector。
const unsigned MAX_DISPLAY_BOXES = 16;
struct DisplayBox {
    int type, score;
    float xmin, xmax, ymin, ymax;
};
struct DetectionSnapshot {
    uint32_t at;
    bool discontinuous;
    int plantCount, bestScore;
    unsigned boxCount;
    DisplayBox boxes[MAX_DISPLAY_BOXES];
};
#endif
