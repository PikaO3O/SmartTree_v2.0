/*
 SmartTree W1 v1.1 — AMB82-MINI 植栽在位「確認」與未確認提醒。
 基底：使用者提供的 SmartTree.ino／Ameba UVCDObjectDetectionLoop。
 YOLOv7-tiny 在板上推論；USB OTG 輸出影像；USB UART 輸出事件。
 只辨識盆栽外觀，不判斷健康、缺水、死亡，也不驅動水泵。
 官方來源與限制請見 README.md。OSD 使用範例字型可顯示的英文。
 */
#include <Arduino.h>
#include <stdio.h>
#include <string.h>
#include "StreamIO.h"
#include "VideoStream.h"
#include "UVCD.h"
#include "NNObjectDetection.h"
#include "VideoStreamOverlay.h"
#include "ObjectClassList.h"
#include "PlantMonitor.h"
#include "DetectionSnapshot.h"
extern "C" {
#include "FreeRTOS.h"
#include "queue.h"
}

#define STREAM_CHANNEL 0
#define CHANNELNN 3
#define NNWIDTH 576
#define NNHEIGHT 320

// 只改這些設定即可；暫不縮小辨識區域，方便你的實物／圖片測試。
const int PLANT_CLASS = 58;
const int MIN_PLANT_SCORE = 50;  // 沿用官方預設 0.5 的接受門檻
const uint32_t CONFIRM_MS = 2000;
const uint32_t MISSING_MS = 5000;
const uint32_t NN_FRESH_MS = 1500; // 1.5 秒無新推論：顯示資料逾時

Video camera_uvcd;
NNObjectDetection ObjDet;
UVCD usb_uvcd;
StreamIO videoStreamer(1, 1);
StreamIO videoStreamerNN(1, 1);
VideoSetting stream_config(VIDEO_FHD, 24, VIDEO_H264, 0);
VideoSetting configNN(NNWIDTH, NNHEIGHT, 10, VIDEO_RGB, 0);
PlantMonitor monitor(CONFIRM_MS, MISSING_MS, NN_FRESH_MS);
QueueHandle_t detectionQueue = NULL;
DetectionSnapshot latest = {};
bool usbConnected = false;
bool needRestart = false;
uint32_t sessionStartedAt = 0;
uint32_t lastStatusAt = 0;

enum LogKind { LOG_CONFIRM, LOG_UNCONFIRMED, LOG_TIMEOUT,
               LOG_USB_DISCONNECT, LOG_USB_CONNECT, LOG_QUEUE_GAP };
struct EventRecord { uint32_t at; LogKind kind; int score, count; };
// 明確宣告帶自訂型別的函式，避免 Arduino 自動原型生成放錯宣告順序。
const char* stateName(PlantMonitor::State state);
const char* logName(LogKind kind);
void printEvent(const EventRecord& event);
void addEvent(LogKind kind, uint32_t at, int score, int count);
void recordDecision(PlantMonitor::Event event, uint32_t at);
const unsigned HISTORY_SIZE = 32;
EventRecord history[HISTORY_SIZE];
unsigned historyHead = 0, historyCount = 0;
char serialLine[32];
unsigned serialLength = 0;
bool discardSerialLine = false;

const char* stateName(PlantMonitor::State state) {
    switch (state) {
        case PlantMonitor::CONFIRMED: return "PLANT_CONFIRMED";
        case PlantMonitor::UNCONFIRMED: return "UNCONFIRMED_CHECK_VIEW";
        case PlantMonitor::NN_TIMEOUT: return "INFERENCE_TIMEOUT";
        case PlantMonitor::OFFLINE: return "USB_OFFLINE";
        default: return "CHECKING";
    }
}

const char* logName(LogKind kind) {
    switch (kind) {
        case LOG_CONFIRM: return "PLANT_CONFIRMED";
        case LOG_UNCONFIRMED: return "PLANT_UNCONFIRMED";
        case LOG_TIMEOUT: return "INFERENCE_TIMEOUT";
        case LOG_USB_DISCONNECT: return "USB_DISCONNECTED";
        case LOG_USB_CONNECT: return "USB_CONNECTED";
        default: return "RESULT_QUEUE_GAP";
    }
}

void printEvent(const EventRecord& event) {
    Serial.print("EVENT,"); Serial.print(event.at);
    Serial.print(','); Serial.print(logName(event.kind));
    Serial.print(','); Serial.print(event.score);
    Serial.print(','); Serial.println(event.count);
}

void addEvent(LogKind kind, uint32_t at, int score, int count) {
    EventRecord event = {at, kind, score, count};
    history[historyHead] = event;
    historyHead = (historyHead + 1) % HISTORY_SIZE;
    if (historyCount < HISTORY_SIZE) ++historyCount;
    printEvent(event);
}

void recordDecision(PlantMonitor::Event event, uint32_t at) {
    if (event == PlantMonitor::PLANT_CONFIRMED)
        addEvent(LOG_CONFIRM, at, latest.bestScore, latest.plantCount);
    else if (event == PlantMonitor::PLANT_UNCONFIRMED)
        addEvent(LOG_UNCONFIRMED, at, latest.bestScore, latest.plantCount);
    else if (event == PlantMonitor::INFERENCE_TIMEOUT)
        addEvent(LOG_TIMEOUT, at, 0, 0);
}

void printStatus() {
    Serial.print("STATUS,"); Serial.print(millis());
    Serial.print(','); Serial.print(stateName(monitor.state()));
    Serial.print(','); Serial.print(latest.bestScore);
    Serial.print(','); Serial.print(latest.plantCount);
    Serial.print(','); Serial.print(monitor.confirms());
    Serial.print(','); Serial.println(monitor.alerts());
}

void handleSerial() {
    while (Serial.available() > 0) {
        const char c = (char)Serial.read();
        if (c == '\r') continue;
        if (c == '\n') {
            if (discardSerialLine) Serial.println("ERR,LINE_TOO_LONG");
            else {
                serialLine[serialLength] = '\0';
                if (strcmp(serialLine, "HISTORY") == 0) {
                    Serial.println("HISTORY_BEGIN,time_ms,event,score,plant_count");
                    const unsigned first = (historyHead + HISTORY_SIZE - historyCount) % HISTORY_SIZE;
                    for (unsigned i = 0; i < historyCount; ++i)
                        printEvent(history[(first + i) % HISTORY_SIZE]);
                    Serial.println("HISTORY_END");
                } else if (strcmp(serialLine, "STATUS") == 0) printStatus();
                else if (strcmp(serialLine, "PING") == 0) Serial.println("SMARTTREE_READY 1");
                else if (serialLength > 0) Serial.println("ERR,UNKNOWN_COMMAND");
            }
            serialLength = 0;
            discardSerialLine = false;
        } else if (!discardSerialLine) {
            if (serialLength < sizeof(serialLine) - 1) serialLine[serialLength++] = c;
            else discardSerialLine = true;
        }
    }
}

// 官方 callback 每一輪推論（包含零目標）都呼叫；本函式不操作 OSD／LED。
void onDetection(std::vector<ObjectDetectionResult> results) {
    static bool previousPublishFailed = false; // 僅由 callback 所在工作使用
    DetectionSnapshot snapshot = {};
    snapshot.at = millis();
    snapshot.discontinuous = previousPublishFailed;
    for (size_t i = 0; i < results.size(); ++i) {
        ObjectDetectionResult item = results[i];
        const int type = item.type();
        if (type < 0 || type >= 80 || !itemList[type].filter) continue;
        if (type == PLANT_CLASS) {
            if (item.score() > snapshot.bestScore) snapshot.bestScore = item.score();
            if (item.score() >= MIN_PLANT_SCORE) ++snapshot.plantCount;
        }
        if (snapshot.boxCount < MAX_DISPLAY_BOXES) {
            DisplayBox& box = snapshot.boxes[snapshot.boxCount++];
            box.type = type; box.score = item.score();
            box.xmin = item.xMin(); box.xmax = item.xMax();
            box.ymin = item.yMin(); box.ymax = item.yMax();
        }
    }
    if (detectionQueue != NULL)
        previousPublishFailed = xQueueSend(detectionQueue, &snapshot, 0) != pdPASS;
}

void updateLeds(uint32_t now) {
    bool blue = false, green = false;
    switch (monitor.state()) {
        case PlantMonitor::CONFIRMED: green = true; break;
        case PlantMonitor::UNCONFIRMED: blue = true; break;
        case PlantMonitor::CHECKING: blue = ((now / 500) % 2) == 0; break;
        case PlantMonitor::NN_TIMEOUT: blue = ((now / 150) % 2) == 0; break;
        default: break;
    }
    // 沿用你先前已測試成功的板上 LED：HIGH 亮、LOW 暗。
    digitalWrite(LED_B, blue ? HIGH : LOW);
    digitalWrite(LED_G, green ? HIGH : LOW);
}

int framePixel(float coordinate, int extent) {
    int value = (int)(coordinate * extent);
    if (value < 0) return 0;
    if (value >= extent) return extent - 1;
    return value;
}

void drawView(uint32_t now) {
    OSD.createBitmap(STREAM_CHANNEL);
    const int width = stream_config.width(), height = stream_config.height();
    if (monitor.state() != PlantMonitor::NN_TIMEOUT &&
        uint32_t(now - latest.at) < NN_FRESH_MS) {
        for (unsigned i = 0; i < latest.boxCount; ++i) {
            const DisplayBox& box = latest.boxes[i];
            const int xmin = framePixel(box.xmin, width), xmax = framePixel(box.xmax, width);
            const int ymin = framePixel(box.ymin, height), ymax = framePixel(box.ymax, height);
            if (xmax <= xmin || ymax <= ymin) continue;
            OSD.drawRect(STREAM_CHANNEL, xmin, ymin, xmax, ymax, 3, OSD_COLOR_WHITE);
            char label[48];
            snprintf(label, sizeof(label), "%s %d", itemList[box.type].objectName, box.score);
            int labelY = ymin - OSD.getTextHeight(STREAM_CHANNEL);
            if (labelY < 0) labelY = 0;
            OSD.drawText(STREAM_CHANNEL, xmin, labelY, label, OSD_COLOR_CYAN);
        }
    }
    // v1.1：每次 drawText 使用短文字，避開板上長字串截斷及部分符號不顯示。
    // 獨立列出欄位；UART 的完整狀態名稱／格式維持原樣。
    const char* screenState = "CHECKING";
    switch (monitor.state()) {
        case PlantMonitor::CONFIRMED: screenState = "PLANT CONFIRMED"; break;
        case PlantMonitor::UNCONFIRMED: screenState = "NOT CONFIRMED"; break;
        case PlantMonitor::NN_TIMEOUT: screenState = "NN DATA TIMEOUT"; break;
        case PlantMonitor::OFFLINE: screenState = "USB OFFLINE"; break;
        default: break;
    }
    const int lineStep = OSD.getTextHeight(STREAM_CHANNEL) + 4;
    char status[32];
    OSD.drawText(STREAM_CHANNEL, 20, 20, screenState, OSD_COLOR_CYAN);
    snprintf(status, sizeof(status), "Plants:%d", latest.plantCount);
    OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep, status, OSD_COLOR_WHITE);
    snprintf(status, sizeof(status), "Score:%d", latest.bestScore);
    OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep * 2, status, OSD_COLOR_WHITE);
    snprintf(status, sizeof(status), "Confirm:%lu", (unsigned long)monitor.confirms());
    OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep * 3, status, OSD_COLOR_WHITE);
    snprintf(status, sizeof(status), "Alert:%lu", (unsigned long)monitor.alerts());
    OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep * 4, status, OSD_COLOR_WHITE);
    if (monitor.state() == PlantMonitor::UNCONFIRMED || monitor.state() == PlantMonitor::NN_TIMEOUT) {
        OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep * 5, "Check camera view", OSD_COLOR_CYAN);
    } else {
        snprintf(status, sizeof(status), "Hold%lus Miss%lus",
                 (unsigned long)(CONFIRM_MS / 1000), (unsigned long)(MISSING_MS / 1000));
        OSD.drawText(STREAM_CHANNEL, 20, 20 + lineStep * 5, status, OSD_COLOR_WHITE);
    }
    OSD.update(STREAM_CHANNEL);
}

void fatalError(const char* message) {
    Serial.print("ERROR,"); Serial.println(message);
    digitalWrite(LED_G, LOW);
    while (true) {
        digitalWrite(LED_B, HIGH); delay(150);
        digitalWrite(LED_B, LOW); delay(150);
    }
}

void setup() {
    Serial.begin(115200);
    pinMode(LED_B, OUTPUT); pinMode(LED_G, OUTPUT);
    digitalWrite(LED_B, LOW); digitalWrite(LED_G, LOW);
    detectionQueue = xQueueCreate(8, sizeof(DetectionSnapshot));
    if (detectionQueue == NULL) fatalError("QUEUE_INIT_FAILED");

    camera_uvcd.configVideoChannel(STREAM_CHANNEL, stream_config);
    camera_uvcd.configVideoChannel(CHANNELNN, configNN);
    usb_uvcd.configVideo(stream_config);
    camera_uvcd.videoInit();
    ObjDet.configVideo(configNN);
    ObjDet.modelSelect(OBJECT_DETECTION, DEFAULT_YOLOV7TINY, NA_MODEL, NA_MODEL);
    ObjDet.setResultCallback(onDetection);
    ObjDet.begin();

    videoStreamer.registerInput(camera_uvcd.getStream(STREAM_CHANNEL));
    videoStreamer.registerOutput(usb_uvcd);
    if (videoStreamer.begin() != 0) fatalError("USB_STREAM_LINK_FAILED");
    camera_uvcd.channelBegin(STREAM_CHANNEL);
    videoStreamerNN.registerInput(camera_uvcd.getStream(CHANNELNN));
    videoStreamerNN.setStackSize();
    videoStreamerNN.setTaskPriority();
    videoStreamerNN.registerOutput(ObjDet);
    if (videoStreamerNN.begin() != 0) fatalError("NN_STREAM_LINK_FAILED");
    camera_uvcd.channelBegin(CHANNELNN);
    usb_uvcd.nnbegin(camera_uvcd.getStream(STREAM_CHANNEL), videoStreamer.linker,
                    STREAM_CHANNEL, camera_uvcd.videostream_status(STREAM_CHANNEL));
    OSD.configVideo(STREAM_CHANNEL, stream_config);
    OSD.begin();
    monitor.reset(millis());
    Serial.println("SMARTTREE_READY 1");
    Serial.println("EVENT_COLUMNS,time_ms,event,score,plant_count");
    Serial.println("STATUS_COLUMNS,time_ms,state,score,plant_count,confirm_events,alert_events");
}

void loop() {
    handleSerial();
    const bool connected = usb_uvcd.isUsbUvcConnected(camera_uvcd.videostream_status(STREAM_CHANNEL));
    if (!connected) {
        if (!needRestart) {
            camera_uvcd.channelEnd(CHANNELNN);
            // 沿用基底範例的 UVC reconnect 流程，維持顯示通道。
            camera_uvcd.channelBegin(STREAM_CHANNEL);
            needRestart = true;
        }
        if (usbConnected) addEvent(LOG_USB_DISCONNECT, millis(), 0, 0);
        usbConnected = false;
        monitor.offline();
        latest = {};
    } else {
        if (!usbConnected) {
            xQueueReset(detectionQueue);
            sessionStartedAt = millis();
            monitor.reconnect(sessionStartedAt);
            latest = {};
            latest.at = sessionStartedAt;
            if (needRestart) {
                camera_uvcd.channelBegin(CHANNELNN);
                camera_uvcd.channelBegin(STREAM_CHANNEL);
                needRestart = false;
            }
            usbConnected = true;
            addEvent(LOG_USB_CONNECT, sessionStartedAt, 0, 0);
        }
        DetectionSnapshot sample;
        while (xQueueReceive(detectionQueue, &sample, 0) == pdPASS) {
            const uint32_t receivedAt = millis();
            // 不接受重連前或已過期的樣本。
            if ((int32_t)(sample.at - sessionStartedAt) < 0 ||
                uint32_t(receivedAt - sample.at) >= NN_FRESH_MS) continue;
            latest = sample;
            if (sample.discontinuous)
                addEvent(LOG_QUEUE_GAP, sample.at, sample.bestScore, sample.plantCount);
            recordDecision(monitor.observe(sample.at, sample.plantCount > 0,
                                           sample.discontinuous), sample.at);
        }
        const uint32_t now = millis();
        recordDecision(monitor.tick(now), now);
        if (monitor.state() == PlantMonitor::NN_TIMEOUT) latest = {};
        drawView(now);
    }
    const uint32_t now = millis();
    updateLeds(now);
    if (uint32_t(now - lastStatusAt) >= 1000) {
        printStatus();
        lastStatusAt = now;
    }
    delay(100);
}
